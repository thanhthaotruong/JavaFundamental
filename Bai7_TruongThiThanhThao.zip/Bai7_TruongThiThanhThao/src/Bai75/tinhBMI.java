package Bai75;

import java.util.Scanner;

public class tinhBMI {
	public static double tinhBMI(double canNang, double ChieuCao){
		double BMI = canNang/(ChieuCao*ChieuCao);
		return BMI;
	}
	public static void danhGiaBMI(double BMI){
		if(BMI<18.5){
			System.out.println("Bạn quá gầy");
		}else if(18.5<BMI && BMI<24.99){
			System.out.println("Bạn có thân hình đầy đặn");
		}else{
			System.out.println("Bạn thừa cân");
		}
	}
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.println("Nhập cân nặng: ");
		double canNang =input.nextDouble();
		System.out.println("Nhập chiều cao: ");
		double chieuCao =input.nextDouble();
		double BMI = tinhBMI(canNang, chieuCao);
		System.out.println("BMI của bạn là : " +tinhBMI(canNang, chieuCao));
		danhGiaBMI(BMI);
	}

}
