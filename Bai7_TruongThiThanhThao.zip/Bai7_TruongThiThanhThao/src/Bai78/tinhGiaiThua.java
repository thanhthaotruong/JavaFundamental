package Bai78;

import java.util.Scanner;

public class tinhGiaiThua {
	public static void tinhGiaiThua(int n){
		int a1 = 1;
		int a2 = 1;
		for (int i = 1; i < n; i++) {
			a1 *= i;
			System.out.print(n + " != " + i + " x ");
		}
		System.out.print(n + " = " + a1 * n + "\n");

		for (int i = 2; i < n; i += 2) {
			a2 *= i;
			System.out.print(n + "!! = " + i + " x ");
		}
		System.out.print(n + " = " + a2 * n + "\n");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input = new Scanner(System.in);
		System.out.print("Nhap n: ");
		int n = input.nextInt();
		tinhGiaiThua(n);
		

	}
}
