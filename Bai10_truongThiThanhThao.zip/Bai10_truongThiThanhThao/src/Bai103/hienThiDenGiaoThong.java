package Bai103;

import Bai102.playOneTwoThree;
enum DenGiaoThong{
	XANH(30) {
		@Override
		public DenGiaoThong chuyenDen() {
			// TODO Auto-generated method stub
			return VANG;
		}
	}, VANG(10) {
		@Override
		public DenGiaoThong chuyenDen() {
			// TODO Auto-generated method stub
			return DO;
		}
	}, DO(30) {
		@Override
		public DenGiaoThong chuyenDen() {
			// TODO Auto-generated method stub
			return XANH;
		}
	};
	private final int soGiay;
	
	private DenGiaoThong(int soGiay){
		this.soGiay=soGiay;
	}
	public abstract DenGiaoThong chuyenDen();

	public int getSoGiay(){
		return soGiay;
	}
}
public class hienThiDenGiaoThong {
	

	public static void main(String[] args) {
		System.out.println("HIEN THI DEN GIAO THONG - SO GIAY - CHUYEN DEN");
		for(DenGiaoThong den : DenGiaoThong.values()){
			System.out.println(den.name() + " - " + den.getSoGiay() +" - "+ den.chuyenDen());
		}
	}

}
