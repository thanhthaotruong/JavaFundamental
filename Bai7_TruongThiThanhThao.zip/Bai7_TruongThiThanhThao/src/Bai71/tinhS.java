package Bai71;

import java.util.Scanner;

public class tinhS {
	public static double tinhTong(double n, double x){
		double s = 1;

		for (int i = 1; i <= n; i++) {
			s = s * (x * x + 1);
		}
		return s;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input = new Scanner(System.in);
		System.out.println("Nhập n: ");
		double n = input.nextDouble();
		System.out.println("Nhập x: ");
		double x = input.nextDouble();
		
		System.out.println("S = " + tinhTong(n, x));
	}

}
