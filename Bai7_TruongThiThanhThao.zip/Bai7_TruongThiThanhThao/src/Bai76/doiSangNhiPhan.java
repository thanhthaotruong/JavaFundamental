package Bai76;

import java.util.Scanner;

public class doiSangNhiPhan {
	public static String xuatChuoiChuaDao(int n){
		String s = "";
		while (n > 0) {
			String term = s.valueOf(n % 2);
			s += term;
			n = n / 2;
		}
		return s;
	}
	public static String revertString(String text) {
		StringBuilder sb = new StringBuilder();
		for (int i = text.length() - 1; i >= 0; i--) {
			sb.append(text.charAt(i));
		}
		return sb.toString();
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input = new Scanner(System.in);
		System.out.print("Nhap n: ");
		int n = input.nextInt();

		String a =  xuatChuoiChuaDao(n);
		System.out.println("Before: " + a);
		System.out.println("After: " + revertString(a));
	}

	
}
