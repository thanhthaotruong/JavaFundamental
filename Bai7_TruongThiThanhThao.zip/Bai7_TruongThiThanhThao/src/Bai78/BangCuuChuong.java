package Bai78;

import java.util.Scanner;

public class BangCuuChuong {

	public static void inBangCuuChuong(int a, int b){
		if (a <= b) {
			for (int i = 1; i <= 9; i++) {
				for (int j = a; j <= b; j++) {
					System.out.print(j + " x " + i + " = " + j * i + "\t");
				}
				System.out.print("\n");
			}
		} else
			System.out.println("");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input = new Scanner(System.in);
		System.out.println("*******************************************************************");
		System.out.println("In bang cuu chuong");
		System.out.println("*******************************************************************");
		System.out.print("Tu so: ");
		int a = input.nextInt();
		System.out.print("Den so: ");
		int b = input.nextInt();
		System.out.println("--------------------------------------------------------------------");
		inBangCuuChuong(a, b);
	}

}
