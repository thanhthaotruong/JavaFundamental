package Bai101;

import java.util.Scanner;

enum tinhToan {
	CONG, TRU, NHAN, CHIA;
	public double tinhToan(double x, double y) {
		switch (this) {
		case CONG:
				return x+y;
		case TRU:
				return x-y;
		case NHAN:
				return x*y;
		case CHIA:
				return x/y;
		default:
			throw new AssertionError("Khong tim thay phep toan yeu cau "+this);
		}
	}
}
public class tinhTongHieuTichThuong {


		


	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.println("Nhập vào số thứ nhất: ");
		double soThu1 = input.nextDouble();
		System.out.println("Nhập vào số thứ hai: ");
		double soThu2 = input.nextDouble();
		double ketqua = tinhToan.CONG.tinhToan(soThu1, soThu2);
		System.out.println(ketqua);
		double ketqua1 = tinhToan.TRU.tinhToan(soThu1, soThu2);
		System.out.println(ketqua1);
		double ketqua2 = tinhToan.NHAN.tinhToan(soThu1, soThu2);
		System.out.println(ketqua2);
		double ketqua3 = tinhToan.CHIA.tinhToan(soThu1, soThu2);
		System.out.println(ketqua3);
		
	}

}
