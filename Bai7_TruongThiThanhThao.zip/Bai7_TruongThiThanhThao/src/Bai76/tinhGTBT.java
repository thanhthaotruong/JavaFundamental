package Bai76;

import java.util.Scanner;

public class tinhGTBT {
	public static int tinhA(int n){
		int a = 0;
		for (int i = 1; i <= n; i += 2) {
			a += i;
		}
		return a;
	}
	public static int tinhB(int n){
		int b = 0;
		for (int i = 0; i <= n; i += 2) {
			b += i;
		}
		return b;
	}
	public static int tinhC(int n){
		int c = 1;
		for (int i = 1; i <= n; i++) {
			c *= i;
		}
		return c;
	}
	public static int tinhD(int n){
		int d = 1;
		for (int i = 1; i <= n; i++) {
			if (i % 3 == 0) {
				d *= i;
			}
		}
		return d;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input = new Scanner(System.in);
		System.out.println("Nhập n: ");
		int n = input.nextInt();
		
		System.out.println("A= " + tinhA(n));
		
		System.out.println("B= " + tinhB(n));
		
		System.out.println("C= " + tinhC(n));
		
		System.out.println("D= " + tinhD(n));
	}

}
