package Bai78;

import java.util.Scanner;

public class tinhGTBT {
	public static double tinhGTBT(int n) {
		int e = 0;
		int i = 2;
		while (i <= n) {
			boolean flag = false;
			int m = i / 2;
			for (int j = 2; j <= m; j++) {
				if (i % j == 0) {
					flag = true;
					break;
				}
			}
			if (flag == false) {
				e += i;
			}
			i++;
		}
		return e;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input = new Scanner(System.in);
		System.out.println("Nhập n: ");
		int n = input.nextInt();
		System.out.println("E= " + tinhGTBT(n));
	}
}
