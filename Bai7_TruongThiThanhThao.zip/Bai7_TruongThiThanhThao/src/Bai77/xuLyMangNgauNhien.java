package Bai77;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Random;

public class xuLyMangNgauNhien {
	public static void taoNgauNhien(int arr[], int n){
		Random random = new Random();
		for(int i =0; i<n;i++){
			arr[i] = random.nextInt(10);
		}
	}
	public static String xuatMang(int arr[]){
		String rs = "";
		for (int item : arr){
			rs += item + " ";
		}
		return rs;
	}
	public static int tinhTong(int arr[], int n){
		int tong=0;
		for(int i=0; i<n;i++){
			tong += arr[i];
		}
		return tong;
	}
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Nhập n: ");
		int n = Integer.parseInt(input.readLine());
		int[] arr= new int[n];
		taoNgauNhien(arr, n);
		System.out.println(xuatMang(arr));
		System.out.println("Tổng: "+tinhTong(arr, n));
	}
}
