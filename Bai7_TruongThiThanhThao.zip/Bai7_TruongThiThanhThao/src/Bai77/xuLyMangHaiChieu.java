package Bai77;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;

import javax.swing.plaf.synth.SynthScrollBarUI;

public class xuLyMangHaiChieu {
	public static void nhapMang(int arr[][], int n, int m) throws NumberFormatException, IOException {
		BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < m; j++) {
				// System.out.print(" a["+i+","+j+"]=");
				arr[i][j] = Integer.parseInt(input.readLine());
				System.out.println(String.valueOf(arr[i][j]));

			}
			System.out.println("\n");

		}
	}

	public static void xuatMang(int arr[][], int n, int m) {
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < m; j++) {
				System.out.print(arr[i][j] + "  ");
			}
			System.out.println("");
		}
	}

	public static double demPTChan(int arr[][], int n, int m) {
		int count = 0;
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < m; j++) {
				if (arr[i][j] % 2 == 0) {
					count = count + 1;
				}
			}
		}
		return count;
	}

	public static double tongPTChan(int arr[][], int n, int m) {
		double tbTong = 0;
		double tongChan = 0;
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < m; j++) {
				if (arr[i][j] % 2 == 0) {
					tongChan += arr[i][j];
				}
				tbTong = tongChan / demPTChan(arr, n, m);
			}

		}
		return tongChan;
	}

	public static double demPTLe(int arr[][], int n, int m) {
		int countLe = 0;
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < m; j++) {
				if (arr[i][j] % 2 != 0) {
					countLe++;
				}
			}
		}
		return countLe;
	}

	public static double tongPTLe(int arr[][], int n, int m) {
		double tbLe = 0;
		double tongLe = 0;
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < m; j++) {
				if (arr[i][j] % 2 != 0) {
					tongLe += arr[i][j];
				}
				tbLe = tongLe / demPTLe(arr, n, m);
			}

		}
		return tongLe;
	}

	public static double pTLN(int arr[][], int m, int n) {
		int d = 0, c = 0;
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < m; j++) {
				if (arr[d][c] < arr[i][j]) {
					d = i;
					c = j;
				}
			}
		}
		return arr[d][c];
	}

	public static double pTNN(int arr[][], int n, int m) {
		int e = 0, f = 0;
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < m; j++) {
				if (arr[e][f] > arr[i][j]) {
					e = i;
					f = j;
				}
			}
		}
		return arr[e][f];
	}

	public static void coPT(int arr[][], int n, int m) {
		int dem = 0;
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < m; j++) {
				if (arr[i][j] < 0) {
					dem++;
				}
			}
		}
		if (dem > 0) {
			System.out.println("ma tran co phan tu am");
		} else {
			System.out.println("ma tran khong co phan tu am");
		}
	}

	public static int demPhantu(int[][] mang, int a) {
		int dem = 0;
		for (int i = 0; i < mang.length; i++) {
			for (int j = 0; j < mang[i].length; j++) {
				if (mang[i][j] == a) {
					dem++;
				}
			}
		}
		return dem;
	}

	public static int demPhantuNhieuNhat(int[][] mang) {
		int dem = 0;
		int tam = 0;
		int tam1 = 0;
		for (int i = 0; i < mang.length; i++) {
			for (int j = 0; j < mang[i].length; j++) {
				dem = demPhantu(mang, mang[i][j]);
				if (dem > tam) {
					tam = dem;
					tam1 = mang[i][j];
				}
			}
		}
		return tam1;
	}

	public static void main(String[] args) throws NumberFormatException, IOException {
		// TODO Auto-generated method stub
		BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Nhap n: ");
		int n = Integer.parseInt(input.readLine());
		System.out.println("Nhap m: ");
		int m = Integer.parseInt(input.readLine());
		int arr[][] = new int[n][m];
		System.out.println("Nhap cac gia tri cho mang:");

		// nhap mang
		nhapMang(arr, n, m);
		// xuat mang
		xuatMang(arr, n, m);

		// dem so pt chan
		System.out.println("So pt chan: " + demPTChan(arr, n, m));
		// tong phan tu chan
		System.out.println("Gia tri TB so chan: " + tongPTChan(arr, n, m));

		// dem so pt le
		System.out.println("Số pt le: " + demPTLe(arr, n, m));
		System.out.println("Gia tri TB so le: " + tongPTLe(arr, n, m));
		// Tim pt lon nhat,
		System.out.println("Phan tu lon nhat trong mang: " + pTLN(arr, m, n));
		// Tim pt NN
		System.out.println("Phan tu nho nhat trong mang: " + pTNN(arr, n, m));
		// co phan tu am hay k
		coPT(arr, n, m);
		// phan tu co so lan xuat hien nhieu nhat
		System.out.println("Phan tu co so lan xuat hien nhieu nhat:" + demPhantuNhieuNhat(arr));
	}
}
