package Bai79;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Random;

public class xuLyMaTranVuong {
	public static int tongTrenDuongCheo(int arr[][], int n) {
		int tong = 0;
		for (int i = 0; i < n; i++) {
			tong += arr[i][i];
		}
		return tong;
	}

	public static int timGTLN(int a[][], int n) {
		int c = 0;
		for (int i = 0; i < n; i++) {
			if (a[c][c] < a[i][i]) {
				c = i;
			}
		}
		return a[c][c];
	}

	public static int timGTNN(int a[][], int n) {
		int d = 0;
		for (int i = 0; i < n; i++) {
			if (a[d][d] > a[i][i]) {
				d = i;
			}
		}
		return a[d][d];
	}

	public static void kiemTraTangDan(int c[][], int n, int m, int k) {
		int m1 = 0;
		for (int i = 0; i < n - 1; i++) {
			if (c[i][k] <= c[i + 1][k]) {
				m1 = 1;
			} else
				m1 = 0;
		}
		if (m1 == 0) {
			System.out.println("Khong tang dan");
		} else {
			System.out.println("Tang dan");
		}

	}

	public static int kiemTraSoNT(int k) {
		if (k == 0 || k == 1)
			return 0;
		else
			for (int i = 2; i < k; i++)
				if (k % i == 0)
					return 0;
		return 1;
	}

	public static void kiemtra(int a[][], int m, int n) {
		int i, j;
		int flag = 1;
		for (i = 0; i < m; i++) {
			for (j = 0; j < n; j++) {
				if (a[i][j] != a[j][i])
					flag = 0;
				break;
			}
		}
		if (flag == 0)
			System.out.println("KHONG DOI XUNG\n");
		else
			System.out.println("DOI XUNG\n");
	}

	public static void laySoNgauNhien(int arr[][], int n) {
		Random random = new Random();
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++) {
				arr[i][j] = random.nextInt(20);
			}
		}
	}

	public static void xuatMaTran(int arr[][], int n) {
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++) {
				System.out.print(arr[i][j] + "  ");
			}
			System.out.println("");
		}
	}

	public static void timSoNT(int arr[][], int n) {
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++) {
				if (kiemTraSoNT(arr[i][j]) == 1) {
					System.out.println("So nguyen to la: " + arr[i][j] + " vi tri: " + i + j);
				}
			}
		}
	}

	public static void nhapMaTranB(int b[][], int m) throws NumberFormatException, IOException {
		BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
		for (int i = 0; i < m; i++) {
			for (int j = 0; j < m; j++) {
				// System.out.print(" a["+i+","+j+"]=");
				b[i][j] = Integer.parseInt(input.readLine());

			}
			System.out.println("\n");

		}
	}

	public static void nhapVaXuatMaTranC(int mangC[][], int h, int arr[][], int b[][]) {
		for (int i = 0; i < h; i++) {
			for (int j = 0; j < h; j++) {
				mangC[i][j] = arr[i][j] + b[i][j];
				System.out.print(mangC[i][j] + "  ");
			}
			System.out.println("");

		}
	}

	public static void main(String[] args) throws NumberFormatException, IOException {

		BufferedReader input = new BufferedReader(new InputStreamReader(System.in));

		System.out.println("Nhap n: ");
		int n = Integer.parseInt(input.readLine());
		int[][] arr = new int[n][n];

		laySoNgauNhien(arr, n);

		// xuat ma tran
		xuatMaTran(arr, n);

		// tinh tong tren duong cheo chinh

		System.out.println("Tong cac gia tri tren duong cheo chinh:" + tongTrenDuongCheo(arr, n));

		// tim gia tri lon nhat tren duong cheo chinh

		System.out.println("Phan tu lon nhat tren duong cheo chinh: " + timGTLN(arr, n));

		// tim gia tri nho nhat tren duong cheo chinh

		System.out.println("Phan tu nho nhat tren duong cheo chinh: " + timGTNN(arr, n));

		// tim so nguyen to trong ma tran
		timSoNT(arr, n);
		// nhap va xuat ma tran vuong b

		System.out.println("Nhap m: ");
		int m = Integer.parseInt(input.readLine());
		int b[][] = new int[m][m];
		System.out.println("Nhap cac gia tri cho mang:");

		// nhap ma tran
		nhapMaTranB(b, m);
		// xuat ma tran

		xuatMaTran(b, m);

		// kiem tra ma tran b co doi xung qua duong cheo chinh k
		kiemtra(b, n, m);

		// nhap va xuat ma tran c

		System.out.println("Nhap h: ");
		int h = Integer.parseInt(input.readLine());
		int mangC[][] = new int[h][h];

		// nhap va xuat ma tran c
		nhapVaXuatMaTranC(mangC, h, arr, b);

		// kiem tra tang dan
		System.out.println("Nhap k: ");
		int k = Integer.parseInt(input.readLine());
		kiemTraTangDan(mangC, h, h, k);

	}

}
