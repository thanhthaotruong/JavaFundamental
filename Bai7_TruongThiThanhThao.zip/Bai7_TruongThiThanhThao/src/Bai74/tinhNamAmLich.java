package Bai74;

import java.util.Scanner;

public class tinhNamAmLich {

	public static String tinhCan(int year){
		int can=year%10;
		String chuoiCan ="";
		switch (can) {
		case 0:
			chuoiCan+= "Canh";
			break;
		case 1:
			chuoiCan+= "Tân";
			break;
		case 2:
			chuoiCan+= "Nhâm";
			break;
		case 3:
			chuoiCan+= "Quý";
			break;
		case 4:
			chuoiCan+= "Giáp";
			break;
		case 5:
			chuoiCan+= "Ất";
			break;
		case 6:
			chuoiCan+= "Bính";
			break;
		case 7:
			chuoiCan+= "Đinh";
			break;
		case 8:
			chuoiCan+= "Mâu";
			break;
		case 9:
			chuoiCan+= "Kỷ";
			break;
		default:
			break;
		}
	return chuoiCan;
	}
	
	public static String tinhChi(int year){
		int chi = year%12;
		String chuoiChi="";
		switch (chi) {
		case 0:
			chuoiChi+="Thân";
			break;
		case 1:
			chuoiChi+="Dậu";
			break;
		case 2:
			chuoiChi+="Tuất";
			break;
		case 3:
			chuoiChi+="Hợi";
			break;
		case 4:
			chuoiChi+="Tý";
			break;
		case 5:
			chuoiChi+="Sửu";
			break;
		case 6:
			chuoiChi+="Dần";
			break;
		case 7:
			chuoiChi+="Mão";
			break;
		case 8:
			chuoiChi+="Thìn";
			break;
		case 9:
			chuoiChi+="Tỵ";
			break;
		case 10:
			chuoiChi+="Ngọ";
			break;
		case 11:
			chuoiChi+="Mùi";
			break;
		default:
			break;
		}
		return chuoiChi;
	}
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.println("Mời bạn nhập năm sinh");
		int year = input.nextInt();
		System.out.println("Tuổi âm lịch của bạn là: "+tinhCan(year)+" "+tinhChi(year));
		
	}

}
