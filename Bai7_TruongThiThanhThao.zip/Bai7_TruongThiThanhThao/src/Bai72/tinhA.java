package Bai72;

import java.util.Scanner;

public class tinhA {

	public static double tinhA(double n, double x){
		double s1 = 1;
		double s2 = 1;
		double s =0;

		for (int i = 1; i <= n; i++) {
			s1 = s1 * (x * x + x + 1);
			s2 = s2 * (x * x - x + 1);
			s=s1+s2;
		}
		return s;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input = new Scanner(System.in);
		System.out.println("Nhập n: ");
		double n = input.nextDouble();
		System.out.println("Nhập x: ");
		double x = input.nextDouble();
		double s1 = 1;
		double s2 = 1;

		for (int i = 1; i <= n; i++) {
			s1 = s1 * (x * x + x + 1);
			s2 = s2 * (x * x - x + 1);
		}
		System.out.println("Cach viet thong thuong : A= " + (s1 + s2));
		System.out.println("Cach viet function: A= "+tinhA(n, x));
	}

}
