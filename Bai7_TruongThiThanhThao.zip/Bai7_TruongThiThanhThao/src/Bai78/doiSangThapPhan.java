package Bai78;

import java.util.Scanner;

public class doiSangThapPhan {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input = new Scanner(System.in);
		System.out.println("Nhập n : ");
		String n = input.nextLine();

		System.out.println(convertBinaryToDecimal(n));
	}

	public static int convertBinaryToDecimal(String binary) {
		int result = 0;
		int length = binary.length() - 1;
		for (int i = 0; i < binary.length(); i++) {
			int numberAtI = Integer.parseInt(binary.charAt(i) + "");
			result += numberAtI * Math.pow(2, length);
			length--;
		}
		return result;
	}
}
