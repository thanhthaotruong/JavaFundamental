package Bai102;

import java.util.Random;
import java.util.Scanner;

public class playOneTwoThree {
	enum choosing {
		SCISSOR(1), PAPER(2), STONE(3);
		private int ketQua;

		private choosing(int ketQua) {
			this.ketQua = ketQua;
		}

		public int getKetQua() {
			return ketQua;
		}
	}

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.println("Bạn có muốn chơi không(y/n)");
		String choi = input.nextLine();
		if (choi.equalsIgnoreCase("y")) {
			boolean tiepTuc = true;

			int playtimes = 0;
			int playermark = 0;
			int computermark = 0;
			int nguoiChon = 0;
			int mayChon = 0;

			while (tiepTuc) {

				System.out.println("Mời bạn nhập vào (s/p/t)");
				String s = input.nextLine();

				switch (s) {
				case "s":
					nguoiChon = choosing.SCISSOR.getKetQua();
					break;
				case "p":
					nguoiChon = choosing.PAPER.getKetQua();
					break;
				case "t":
					nguoiChon = choosing.STONE.getKetQua();
				}

				mayChon = new Random().nextInt(3);
				System.out.println(mayChon);

				if (mayChon == nguoiChon) {
					System.out.println("Ngang tài ngang sức");
				} else {
					if (nguoiChon == 1) {
						if (mayChon == 2) {
							System.out.println("Chúc mừng bạn đã thắng");
							playermark += 1;
						} else if (mayChon == 3) {
							System.out.println("Oh oh, bạn thua rồi");
							computermark += 1;
						}
					} else if (nguoiChon == 2) {
						if (mayChon == 3) {
							System.out.println("Chúc mừng bạn đã thắng");
							playermark += 1;
						} else if (mayChon == 1) {
							System.out.println("Oh oh, bạn thua rồi");
							computermark += 1;
						}
					} else if (nguoiChon == 3) {
						if (mayChon == 1) {
							System.out.println("Chúc mừng bạn đã thắng");
							playermark += 1;
						} else if (mayChon == 2) {
							System.out.println("Oh oh, bạn thua rồi");
							computermark += 1;
						}
					}
				}
				playtimes++;
				if (playermark == 5 || computermark == 5) {
					tiepTuc = false;
				}

			}
			System.out.println("Tồng số lần chơi:" + playtimes);
			if (playermark > computermark) {
				System.out.println("bạn là người chiến thắng");
			} else {
				System.out.println("bạn thua rồi");
			}
		}

	}

}
