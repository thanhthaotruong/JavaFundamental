package Bai73;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;

public class timKiemTrongMang {

	public static String xuatMang(int arr[], int n) throws NumberFormatException, IOException{
		BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
		
		for (int i = 0; i < n; i++) {
			arr[i] = Integer.parseInt(input.readLine());
		}
		String rs = "";
		for (int item : arr) {
			rs += item + " ";
		}
		return rs;
	}
	
	public static boolean isLarger(int[] numbers,int x){
		for (int i = 0; i < numbers.length - 1; i++) {
			if (x < numbers[i]) {
				return false;
			}
		}
		return true;
	}
	public static void main(String[] args) throws NumberFormatException, IOException {
		// TODO Auto-generated method stub
		BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Nhập n: ");
		int n = Integer.parseInt(input.readLine());
		int arr[] = new int[n];
		System.out.println("Nhap cac gia tri cho mang:");
		
		//nhap mang
		System.out.println("Mang da nhap :" +xuatMang(arr, n));
		
		System.out.println("Nhap x: ");
		int x = Integer.parseInt(input.readLine());
		Arrays.sort(arr);
		System.out.println(x + " xuat hien tai vi tri " + Arrays.binarySearch(arr, x));
	}
	

}
