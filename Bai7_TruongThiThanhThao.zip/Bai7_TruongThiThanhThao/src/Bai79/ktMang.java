package Bai79;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class ktMang {
	public static String xuatMang(int arr[], int n) throws NumberFormatException, IOException {
		BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
		for (int i = 0; i < n; i++) {
			arr[i] = Integer.parseInt(input.readLine());
		}
		String rs = "";
		for (int item : arr) {
			rs += item + " ";
		}
		return rs;
	}

	public static boolean laTangDan(int[] numbers) {
		for (int i = 0; i < numbers.length - 1; i++) {
			if (numbers[i] > numbers[i + 1]) {
				return false;
			}
		}
		return true;
	}

	public static boolean laGiamDan(int[] numbers) {
		for (int i = 0; i < numbers.length - 1; i++) {
			if (numbers[i] < numbers[i + 1]) {
				return false;
			}
		}
		return true;
	}

	public static void checkIndexOf6(int[] numbers) {
		for (int i = 0; i < numbers.length; i++) {
			int lastNumber = numbers[i] % 10;
			if (lastNumber == 6) {
				System.out.println("Number " + numbers[i] + " at " + (i + 1));
				return;
			}
		}
		System.out.println("Number not exist");
	}

	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Nhap n: ");
		int n = Integer.parseInt(input.readLine());
		int arr[] = new int[n];
		System.out.println("Nhap cac gia tri cho mang:");

		System.out.println("Mang da nhap :" + xuatMang(arr, n));

		System.out.println(laTangDan(arr) ? "mang da xep tang dan" : "mang chua xep tang dan");
		System.out.println(laGiamDan(arr) ? "mang da xep giam dan" : "mang chua xep giam dan");
		checkIndexOf6(arr);
	}

}
