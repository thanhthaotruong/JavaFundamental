package Bai79;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class timCapSoMangMotChieu {

	public static String xuatMang(int arr[]) throws NumberFormatException, IOException {
		BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
		for (int i = 0; i < 5; i++) {
			arr[i] = Integer.parseInt(input.readLine());
		}
		String rs = "";
		for (int item : arr) {
			rs += item + " ";
		}
		return rs;
	}

	public static void soChiaHet(int[] numbers) {
		for (int i = 0; i < numbers.length; i++) {
			for (int j = 0; j < numbers.length; j++) {
				int modNumber = numbers[j] % numbers[i];
				if (modNumber == 0 && i != j) {
					System.out.println(numbers[j] + "&" + numbers[i]);
				}
			}
		}
	}

	public static void gapDoi(int[] numbers) {
		for (int i = 0; i < numbers.length; i++) {
			for (int j = 0; j < numbers.length; j++) {

				if (numbers[j] == 2 * numbers[i]) {
					System.out.println(numbers[j] + "&" + numbers[i]);
				}
			}
		}
	}

	public static void tong2So(int[] numbers) {
		for (int i = 0; i < numbers.length; i++) {
			for (int j = 0; j < numbers.length; j++) {
				int number = numbers[j] + numbers[i];
				if (number == 8 && i != j) {
					System.out.println(numbers[j] + "&" + numbers[i]);
				}
			}
		}
	}

	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
		int arr[] = new int[5];
		System.out.println("Nhap cac gia tri cho mang:");

		System.out.println("Mang da nhap :" + xuatMang(arr));
		System.out.println("cap so chia het");
		soChiaHet(arr);
		System.out.println("so gap doi");
		gapDoi(arr);
		System.out.println("tong hai so bang 8");
		tong2So(arr);
	}

}
