package Bai76;

import java.util.Scanner;

public class ktSoNT {
	public static void kiemTraSNT(int x){
		 if (x >= 2) {
	            int m = x / 2;
	            boolean flag = false;
	            for (int i = 2; i <= m; i++) {
	                if (x % i == 0) {
	                    flag = true;
	                    break;
	                }
	            }
	            if (flag == true) {
	                System.out.println(x + " KHONG phai so nguyen to!");
	            } else {
	                System.out.println(x + " la so nguyen to!");
	            }
	        } else {
	            System.out.println(x + " KHONG phai so nguyen to!");
	        }

	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input = new Scanner(System.in);
		System.out.println("Nhập x : ");
		int x = input.nextInt();

		kiemTraSNT(x);
	}
}
